# Expo-Post

11/16/2023
As a HS, I created this idea to be, lets say, a "rip off" twitter. THIS CAN AND WILL LOOK DIFFERENT, but I need help in your spare time if you'd like.

It would be lovely as I really do not know what I'm doing,
but using what I do indeed know.

I know express (js) and sqlite3 (sql). If it's better in a different way, feel free. I will adapt. This 'company' is just something I can use to dissosiate myself as a whole to possibly a group if it goes far.

<https://expo-post.com>

Note:
Config File:
config.js is, well, exactly like "config copy.js" but as a hidden file. This is to eventually hide things down the line without having to worry about 'config.js' being exposed.
And yes. I know I will, by hand, have to edit it using nano but that is not my concern.
