exports.config = {
    "PORT":3000,
    "DEV":true
}